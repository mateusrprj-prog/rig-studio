import './style.css';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';

const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = `
  <header class="topbar">
    <div class="brand"><span class="brand-mark">R</span><div><b>RIG STUDIO</b><small>3D RIGGING WORKSPACE</small></div></div>
    <button id="fitBtn" class="icon-btn" title="Enquadrar modelo">⌗</button>
  </header>
  <main>
    <section class="viewport-wrap">
      <div id="viewport"></div>
      <div class="viewport-hud"><span id="modeLabel">VIEW MODE</span><span id="fpsLabel">READY</span></div>
      <div class="view-help">arraste para orbitar · pinça para zoom</div>
      <div id="emptyState" class="empty-state"><div class="cube">◇</div><b>Seu espaço de trabalho está vazio</b><span>Importe um modelo 3D para começar.</span><button id="emptyImport" class="primary">IMPORTAR MODELO</button><small>GLB · GLTF · FBX</small></div>
    </section>
    <section class="panel">
      <div class="panel-head"><div><small>WORKSPACE</small><h1 id="modelName">Nenhum modelo</h1></div><span id="modelBadge" class="badge">SEM MODELO</span></div>
      <div class="stats">
        <div><small>OBJETOS</small><b id="objectCount">0</b></div>
        <div><small>MALHAS</small><b id="meshCount">0</b></div>
        <div><small>OSSOS</small><b id="boneCount">0</b></div>
      </div>
      <div class="section-title">FERRAMENTAS</div>
      <div class="tool-grid">
        <button id="importBtn" class="tool"><span>＋</span><b>Importar</b><small>GLB / FBX</small></button>
        <button id="boneModeBtn" class="tool"><span>⌁</span><b>Adicionar osso</b><small>Construir cadeia</small></button>
        <button id="undoBoneBtn" class="tool"><span>↶</span><b>Desfazer osso</b><small>Último osso</small></button>
        <button id="clearBonesBtn" class="tool"><span>⌫</span><b>Limpar rig</b><small>Remover esqueleto</small></button>
      </div>
      <div class="tip" id="tipBox"><b>Como começar</b><span>1. Importe um modelo GLB ou FBX.<br>2. Ative “Adicionar osso”.<br>3. Toque na superfície do modelo para posicionar os ossos em sequência.</span></div>
      <div class="section-title">HIERARQUIA DO RIG</div>
      <div id="boneList" class="bone-list"><span class="muted">Nenhum osso criado.</span></div>
      <div class="bottom-actions"><button id="resetViewBtn" class="secondary">REINICIAR CÂMERA</button><button id="helpBtn" class="secondary">GUIA RÁPIDO</button></div>
    </section>
  </main>
  <input id="fileInput" type="file" accept=".glb,.gltf,.fbx,model/gltf-binary,model/gltf+json" hidden />
  <div id="toast" class="toast"></div>
`;

const viewport = document.querySelector<HTMLDivElement>('#viewport')!;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x151a24);
const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 2000);
camera.position.set(3, 2.2, 4);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
viewport.appendChild(renderer.domElement);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.target.set(0, 1, 0);
scene.add(new THREE.HemisphereLight(0xffffff, 0x4a5368, 2));
const keyLight = new THREE.DirectionalLight(0xffffff, 2.4);
keyLight.position.set(4, 8, 5);
keyLight.castShadow = true;
scene.add(keyLight);
const grid = new THREE.GridHelper(20, 40, 0x536078, 0x30394a);
scene.add(grid);
const axes = new THREE.AxesHelper(0.6);
scene.add(axes);

let model: THREE.Object3D | null = null;
let rootBone: THREE.Bone | null = null;
let lastBone: THREE.Bone | null = null;
let skeletonHelper: THREE.SkeletonHelper | null = null;
let boneCount = 0;
let addBoneMode = false;
let toastTimer = 0;
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const toast = (message: string) => {
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  window.clearTimeout(toastTimer); toastTimer = window.setTimeout(() => el.classList.remove('show'), 2600);
};
const updateStats = () => {
  let objects = 0, meshes = 0;
  if (model) model.traverse(o => { objects++; if ((o as THREE.Mesh).isMesh) meshes++; });
  $('objectCount').textContent = String(objects);
  $('meshCount').textContent = String(meshes);
  $('boneCount').textContent = String(boneCount);
  $('modelBadge').textContent = model ? 'MODELO CARREGADO' : 'SEM MODELO';
  $('modelName').textContent = model?.name || 'Nenhum modelo';
  $('emptyState').classList.toggle('hidden', !!model);
};
const frameObject = (obj: THREE.Object3D) => {
  const box = new THREE.Box3().setFromObject(obj);
  if (box.isEmpty()) return;
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z, 0.1);
  const distance = maxDim * 2.4;
  controls.target.copy(center);
  camera.position.copy(center).add(new THREE.Vector3(distance * 0.8, distance * 0.55, distance));
  camera.near = Math.max(maxDim / 1000, 0.001);
  camera.far = maxDim * 100;
  camera.updateProjectionMatrix();
  controls.update();
};
const refreshBoneList = () => {
  const list = $('boneList');
  if (!rootBone) { list.innerHTML = '<span class="muted">Nenhum osso criado.</span>'; return; }
  const rows: string[] = [];
  rootBone.traverse(o => { if ((o as THREE.Bone).isBone) rows.push(`<div class="bone-row"><span>◈</span><b>${o.name}</b></div>`); });
  list.innerHTML = rows.join('');
};
const removeRig = () => {
  if (skeletonHelper) { scene.remove(skeletonHelper); skeletonHelper = null; }
  if (rootBone) scene.remove(rootBone);
  rootBone = null; lastBone = null; boneCount = 0;
  updateStats(); refreshBoneList();
};
const loadModel = async (file: File) => {
  const ext = file.name.split('.').pop()?.toLowerCase();
  const url = URL.createObjectURL(file);
  try {
    let loaded: THREE.Object3D;
    if (ext === 'fbx') {
      loaded = await new FBXLoader().loadAsync(url);
    } else if (ext === 'glb' || ext === 'gltf') {
      const result = await new GLTFLoader().loadAsync(url);
      loaded = result.scene;
    } else throw new Error('Formato não suportado.');
    if (model) scene.remove(model);
    removeRig();
    model = loaded;
    model.name = file.name;
    model.traverse(o => {
      if ((o as THREE.Mesh).isMesh) {
        const mesh = o as THREE.Mesh;
        mesh.castShadow = true; mesh.receiveShadow = true;
        if (mesh.material) {
          const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          materials.forEach(m => { if ('side' in m) (m as THREE.Material).side = THREE.DoubleSide; });
        }
      }
    });
    scene.add(model);
    frameObject(model);
    updateStats();
    toast(`Modelo importado: ${file.name}`);
  } catch (e) {
    console.error(e);
    toast(e instanceof Error ? e.message : 'Não foi possível importar o arquivo.');
  } finally { URL.revokeObjectURL(url); }
};
const toggleBoneMode = () => {
  if (!model) { toast('Importe um modelo antes de criar ossos.'); return; }
  addBoneMode = !addBoneMode;
  $('boneModeBtn').classList.toggle('active', addBoneMode);
  $('modeLabel').textContent = addBoneMode ? 'BONE PLACEMENT' : 'VIEW MODE';
  $('tipBox').innerHTML = addBoneMode
    ? '<b>Posicionamento de ossos ativo</b><span>Toque no modelo para criar o primeiro osso e continue tocando para criar os filhos na sequência. Desative o modo para navegar pela câmera.</span>'
    : '<b>Modo de visualização</b><span>Arraste para orbitar e use pinça para zoom. Reative Adicionar osso para continuar a cadeia.</span>';
  toast(addBoneMode ? 'Toque na superfície para posicionar um osso.' : 'Modo de visualização ativado.');
};
const placeBone = (point3: THREE.Vector3) => {
  const bone = new THREE.Bone();
  bone.name = `Bone_${String(boneCount + 1).padStart(2, '0')}`;
  if (!rootBone) {
    rootBone = bone;
    bone.position.copy(point3);
    scene.add(rootBone);
  } else if (lastBone) {
    const parentWorld = new THREE.Vector3();
    lastBone.getWorldPosition(parentWorld);
    bone.position.copy(point3).sub(parentWorld);
    lastBone.add(bone);
  }
  lastBone = bone;
  boneCount++;
  if (skeletonHelper) { scene.remove(skeletonHelper); }
  skeletonHelper = new THREE.SkeletonHelper(rootBone!);
  skeletonHelper.material = new THREE.LineBasicMaterial({ color: 0x62e6c5, depthTest: false });
  scene.add(skeletonHelper);
  updateStats(); refreshBoneList();
};
renderer.domElement.addEventListener('pointerdown', event => {
  if (!addBoneMode || !model) return;
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObject(model, true);
  if (hits.length) placeBone(hits[0].point);
  else toast('Toque em uma superfície do modelo.');
});
const importFile = () => $('fileInput').click();
$('importBtn').addEventListener('click', importFile);
$('emptyImport').addEventListener('click', importFile);
$('fileInput').addEventListener('change', e => {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (file) void loadModel(file);
  (e.target as HTMLInputElement).value = '';
});
$('boneModeBtn').addEventListener('click', toggleBoneMode);
$('clearBonesBtn').addEventListener('click', () => { removeRig(); toast('Esqueleto removido.'); });
$('undoBoneBtn').addEventListener('click', () => {
  if (!lastBone || !rootBone) { toast('Não há ossos para desfazer.'); return; }
  const parent = lastBone.parent;
  if (parent) parent.remove(lastBone);
  if (boneCount > 1 && parent instanceof THREE.Bone) lastBone = parent;
  else { scene.remove(rootBone); rootBone = null; lastBone = null; }
  boneCount = Math.max(0, boneCount - 1);
  if (skeletonHelper) { scene.remove(skeletonHelper); skeletonHelper = rootBone ? new THREE.SkeletonHelper(rootBone) : null; if (skeletonHelper) { skeletonHelper.material = new THREE.LineBasicMaterial({color:0x62e6c5, depthTest:false}); scene.add(skeletonHelper); } }
  updateStats(); refreshBoneList(); toast('Último osso removido.');
});
$('fitBtn').addEventListener('click', () => model ? frameObject(model) : toast('Importe um modelo primeiro.'));
$('resetViewBtn').addEventListener('click', () => { camera.position.set(3,2.2,4); controls.target.set(0,1,0); controls.update(); });
$('helpBtn').addEventListener('click', () => toast('Importe GLB/FBX. Ative Adicionar osso e toque no modelo para criar uma cadeia.'));
const resize = () => {
  const w = viewport.clientWidth, h = viewport.clientHeight;
  if (!w || !h) return;
  camera.aspect = w / h; camera.updateProjectionMatrix(); renderer.setSize(w, h);
};
new ResizeObserver(resize).observe(viewport); resize();
const animate = () => { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); };
animate();
updateStats();


# RIG STUDIO — v0.1.0

Primeira base funcional do RIG STUDIO: viewport 3D móvel, importação de arquivos GLB/GLTF e FBX, navegação por toque e criação visual de uma cadeia de ossos (`THREE.Bone`) posicionados sobre o modelo.

## O que funciona nesta versão
- Importação local de GLB, glTF e FBX.
- Viewport Three.js com órbita, zoom e enquadramento automático.
- Contagem de objetos e malhas.
- Modo de posicionamento de ossos: toque na superfície para criar uma cadeia hierárquica.
- Lista de ossos, desfazer último osso e limpar esqueleto.
- Auto Rig humanoide beta: gera hierarquia de 22 ossos para personagens em pé/T-pose e aplica pesos iniciais de skinning às malhas estáticas.
- Pipeline GitHub Actions para gerar APK Android de depuração.

## Limitações honestas da v0.1
Esta é a primeira fundação, não um rigging completo ainda. Os ossos são criados e exibidos como hierarquia visual, mas ainda não estão ligados à malha por skinning/weights; não há pintura de pesos, IK/FK nem exportação de rig nesta versão. O Auto Rig beta usa proporções estimadas pelo volume do modelo e pesos automáticos por proximidade dos segmentos; não substitui revisão manual e pode falhar em modelos fora de T-pose, com eixo vertical diferente ou anatomia não humana. FBX/GLB são importados para visualização, não reexportados.

## Desenvolvimento no Android
1. Crie um repositório vazio no GitHub.
2. Extraia este ZIP e envie todos os arquivos para a raiz do repositório (a pasta `.github` também).
3. Abra a aba **Actions** do repositório.
4. Execute **Build RIG STUDIO APK** (ou faça push na branch `main`).
5. Quando terminar, abra a execução e baixe o artifact `rig-studio-debug-apk`.
6. Extraia o artifact e instale `app-debug.apk` no POCO X7 Pro.

O APK é de depuração. Para distribuição pública, será necessário configurar assinatura de release.

## Rodar/testar no navegador
Requer Node.js:
```bash
npm install
npm run dev
```

## Stack
- Three.js
- TypeScript
- Vite
- Capacitor 7
- GitHub Actions

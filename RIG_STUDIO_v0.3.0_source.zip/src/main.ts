import './style.css';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';

const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = `
  <header class="topbar">
    <div class="brand"><span class="brand-mark">R</span><div><b>RIG STUDIO</b><small>3D RIGGING WORKSPACE</small></div></div>
    <button id="fitBtn" class="icon-btn" title="Enquadrar modelo">⌗</button>
  </header>
  <main>
    <section class="viewport-wrap">
      <div id="viewport"></div>
      <div class="viewport-hud"><span id="modeLabel">VIEW MODE</span><span id="fpsLabel">READY</span></div>
      <div class="view-help">arraste para orbitar · pinça para zoom</div>
      <div id="emptyState" class="empty-state"><div class="cube">◇</div><b>Seu espaço de trabalho está vazio</b><span>Importe um modelo 3D para começar.</span><button id="emptyImport" class="primary">IMPORTAR MODELO</button><small>GLB · GLTF · FBX · OBJ · STL</small></div>
    </section>
    <section class="panel">
      <div class="panel-head"><div><small>WORKSPACE</small><h1 id="modelName">Nenhum modelo</h1></div><span id="modelBadge" class="badge">SEM MODELO</span></div>
      <div class="stats">
        <div><small>OBJETOS</small><b id="objectCount">0</b></div>
        <div><small>MALHAS</small><b id="meshCount">0</b></div>
        <div><small>OSSOS</small><b id="boneCount">0</b></div>
      </div>
      <div class="section-title">FERRAMENTAS</div>
      <div class="tool-grid">
        <button id="importBtn" class="tool"><span>＋</span><b>Importar</b><small>GLB / FBX / OBJ / STL</small></button>
        <button id="autoRigBtn" class="tool auto-rig-tool"><span>✣</span><b>Auto Rig humanoide</b><small>Beta · T-pose</small></button>
        <button id="boneModeBtn" class="tool"><span>⌁</span><b>Adicionar osso</b><small>Construir cadeia</small></button>
        <button id="undoBoneBtn" class="tool"><span>↶</span><b>Desfazer osso</b><small>Último osso</small></button>
        <button id="clearBonesBtn" class="tool"><span>⌫</span><b>Limpar rig</b><small>Remover esqueleto</small></button>
      </div>
      <div class="tip" id="tipBox"><b>Como começar</b><span>Importe um personagem humanoide em pé, preferencialmente em T-pose. Use Auto Rig humanoide para gerar uma estrutura inicial e pesos automáticos. O resultado beta pode precisar de correções.</span></div>
      <div class="section-title">HIERARQUIA DO RIG</div>
      <div id="boneList" class="bone-list"><span class="muted">Nenhum osso criado.</span></div>
      <div class="section-title">TESTE DE DEFORMAÇÃO</div>
      <div id="posePanel" style="display:grid;gap:10px;padding:12px;background:#1b2230;border:1px solid #303b4e;border-radius:12px">
        <label style="font-size:12px;color:#aab6c9">OSSO SELECIONADO
          <select id="poseBoneSelect" disabled style="display:block;width:100%;margin-top:6px;padding:10px;background:#111722;color:#eef3fb;border:1px solid #3b465b;border-radius:8px"></select>
        </label>
        <div style="display:grid;gap:5px">
          <label style="display:flex;justify-content:space-between;font-size:12px;color:#c5d0df">Rotação X <output id="poseXValue">0°</output></label>
          <input id="poseX" type="range" min="-90" max="90" step="1" value="0" disabled style="width:100%;accent-color:#62e6c5">
        </div>
        <div style="display:grid;gap:5px">
          <label style="display:flex;justify-content:space-between;font-size:12px;color:#c5d0df">Rotação Y <output id="poseYValue">0°</output></label>
          <input id="poseY" type="range" min="-90" max="90" step="1" value="0" disabled style="width:100%;accent-color:#62e6c5">
        </div>
        <div style="display:grid;gap:5px">
          <label style="display:flex;justify-content:space-between;font-size:12px;color:#c5d0df">Rotação Z <output id="poseZValue">0°</output></label>
          <input id="poseZ" type="range" min="-90" max="90" step="1" value="0" disabled style="width:100%;accent-color:#62e6c5">
        </div>
        <div style="display:flex;gap:8px">
          <button id="resetBonePose" class="secondary" disabled style="flex:1">RESETAR OSSO</button>
          <button id="resetAllPose" class="secondary" disabled style="flex:1">RESETAR POSE</button>
        </div>
        <small id="poseHint" style="color:#93a2b8;line-height:1.4">Gere o Auto Rig humanoide para testar a deformação da malha.</small>
      </div>
      <div class="bottom-actions"><button id="resetViewBtn" class="secondary">REINICIAR CÂMERA</button><button id="helpBtn" class="secondary">GUIA RÁPIDO</button></div>
    </section>
  </main>
  <input id="fileInput" type="file" accept=".glb,.gltf,.fbx,.obj,.stl,model/gltf-binary,model/gltf+json,application/octet-stream" hidden />
  <div id="toast" class="toast"></div>
`;

const viewport = document.querySelector<HTMLDivElement>('#viewport')!;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x151a24);
const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 2000);
camera.position.set(3, 2.2, 4);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
viewport.appendChild(renderer.domElement);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.target.set(0, 1, 0);
scene.add(new THREE.HemisphereLight(0xffffff, 0x4a5368, 2));
const keyLight = new THREE.DirectionalLight(0xffffff, 2.4);
keyLight.position.set(4, 8, 5);
keyLight.castShadow = true;
scene.add(keyLight);
const grid = new THREE.GridHelper(20, 40, 0x536078, 0x30394a);
scene.add(grid);
const axes = new THREE.AxesHelper(0.6);
scene.add(axes);

let model: THREE.Object3D | null = null;
let rootBone: THREE.Bone | null = null;
let lastBone: THREE.Bone | null = null;
let skeletonHelper: THREE.SkeletonHelper | null = null;
let boneCount = 0;
let autoRigged = false;
let poseBones: THREE.Bone[] = [];
let selectedPoseBone: THREE.Bone | null = null;
let restPoseRotations = new Map<THREE.Bone, THREE.Euler>();

const riggedMeshes: Array<{ parent: THREE.Object3D; original: THREE.Mesh; skinned: THREE.SkinnedMesh; index: number }> = [];
let addBoneMode = false;
let toastTimer = 0;
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const toast = (message: string) => {
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  window.clearTimeout(toastTimer); toastTimer = window.setTimeout(() => el.classList.remove('show'), 2600);
};
const updateStats = () => {
  let objects = 0, meshes = 0;
  if (model) model.traverse(o => { objects++; if ((o as THREE.Mesh).isMesh) meshes++; });
  $('objectCount').textContent = String(objects);
  $('meshCount').textContent = String(meshes);
  $('boneCount').textContent = String(boneCount);
  $('modelBadge').textContent = model ? 'MODELO CARREGADO' : 'SEM MODELO';
  $('modelName').textContent = model?.name || 'Nenhum modelo';
  $('emptyState').classList.toggle('hidden', !!model);
};
const frameObject = (obj: THREE.Object3D) => {
  const box = new THREE.Box3().setFromObject(obj);
  if (box.isEmpty()) return;
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z, 0.1);
  const distance = maxDim * 2.4;
  controls.target.copy(center);
  camera.position.copy(center).add(new THREE.Vector3(distance * 0.8, distance * 0.55, distance));
  camera.near = Math.max(maxDim / 1000, 0.001);
  camera.far = maxDim * 100;
  camera.updateProjectionMatrix();
  controls.update();
};
const refreshBoneList = () => {
  const list = $('boneList');
  if (!rootBone) { list.innerHTML = '<span class="muted">Nenhum osso criado.</span>'; return; }
  const rows: string[] = [];
  rootBone.traverse(o => { if ((o as THREE.Bone).isBone) rows.push(`<div class="bone-row"><span>◈</span><b>${o.name}</b></div>`); });
  list.innerHTML = rows.join('');
};
const updatePoseSliders = () => {
  const bone = selectedPoseBone;
  const values = bone ? [bone.rotation.x, bone.rotation.y, bone.rotation.z].map(v => Math.round(THREE.MathUtils.radToDeg(v))) : [0, 0, 0];
  (['X', 'Y', 'Z'] as const).forEach((axis, index) => {
    const slider = $<HTMLInputElement>('pose' + axis);
    const output = $('pose' + axis + 'Value');
    slider.value = String(values[index]);
    output.textContent = values[index] + '°';
  });
};

const syncPosePanel = () => {
  const select = $<HTMLSelectElement>('poseBoneSelect');
  const enabled = autoRigged && !!rootBone;
  poseBones = [];
  if (rootBone) rootBone.traverse(object => {
    if ((object as THREE.Bone).isBone) poseBones.push(object as THREE.Bone);
  });
  select.innerHTML = '';
  poseBones.forEach((bone, index) => {
    const option = document.createElement('option');
    option.value = String(index);
    option.textContent = bone.name;
    select.appendChild(option);
  });
  if (!selectedPoseBone || !poseBones.includes(selectedPoseBone)) selectedPoseBone = poseBones[0] || null;
  if (selectedPoseBone) select.value = String(poseBones.indexOf(selectedPoseBone));
  select.disabled = !enabled || poseBones.length === 0;
  (['X', 'Y', 'Z'] as const).forEach(axis => {
    $<HTMLInputElement>('pose' + axis).disabled = !enabled || !selectedPoseBone;
  });
  $<HTMLButtonElement>('resetBonePose').disabled = !enabled || !selectedPoseBone;
  $<HTMLButtonElement>('resetAllPose').disabled = !enabled;
  $('poseHint').textContent = enabled
    ? 'Arraste os controles para girar um osso e observar como os pesos automáticos deformam a malha. Use ângulos pequenos para avaliar o resultado.'
    : 'Gere o Auto Rig humanoide para testar a deformação da malha.';
  updatePoseSliders();
};

const applyPoseRotation = (axis: 'x' | 'y' | 'z', value: string) => {
  if (!selectedPoseBone || !autoRigged) return;
  selectedPoseBone.rotation[axis] = THREE.MathUtils.degToRad(Number(value));
  $('pose' + axis.toUpperCase() + 'Value').textContent = value + '°';
  selectedPoseBone.updateWorldMatrix(true, true);
  if (skeletonHelper) skeletonHelper.update();
};

const resetSelectedPoseBone = () => {
  if (!selectedPoseBone) return;
  const rest = restPoseRotations.get(selectedPoseBone);
  if (rest) selectedPoseBone.rotation.copy(rest);
  updatePoseSliders();
  selectedPoseBone.updateWorldMatrix(true, true);
  if (skeletonHelper) skeletonHelper.update();
};

const resetEntirePose = () => {
  restPoseRotations.forEach((rotation, bone) => bone.rotation.copy(rotation));
  updatePoseSliders();
  rootBone?.updateWorldMatrix(true, true);
  if (skeletonHelper) skeletonHelper.update();
  toast('Pose original restaurada.');
};

const restoreAutoRigMeshes = () => {
  for (const item of [...riggedMeshes].reverse()) {
    item.parent.add(item.original);
    item.parent.remove(item.skinned);
    const current = item.parent.children.indexOf(item.original);
    if (current >= 0) {
      item.parent.children.splice(current, 1);
      item.parent.children.splice(Math.min(item.index, item.parent.children.length), 0, item.original);
    }
  }
  riggedMeshes.length = 0;
  autoRigged = false;
};
const removeRig = () => {
  if (skeletonHelper) { scene.remove(skeletonHelper); skeletonHelper = null; }
  restoreAutoRigMeshes();
  if (rootBone?.parent) rootBone.parent.remove(rootBone);
  rootBone = null; lastBone = null; boneCount = 0;
  selectedPoseBone = null;
  poseBones = [];
  restPoseRotations.clear();
  syncPosePanel();
  updateStats(); refreshBoneList();
};
const MAX_MODEL_SIZE = 100 * 1024 * 1024;
const loadModel = async (file: File) => {
  if (file.size > MAX_MODEL_SIZE) {
    toast('Arquivo muito grande (' + (file.size / 1024 / 1024).toFixed(1) + ' MB). O limite atual é 100 MB.');
    return;
  }
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const url = URL.createObjectURL(file);
  try {
    let loaded: THREE.Object3D;
    if (ext === 'fbx') {
      loaded = await new FBXLoader().loadAsync(url);
    } else if (ext === 'glb' || ext === 'gltf') {
      const result = await new GLTFLoader().loadAsync(url);
      loaded = result.scene;
    } else if (ext === 'obj') {
      loaded = await new OBJLoader().loadAsync(url);
    } else if (ext === 'stl') {
      const geometry = await new STLLoader().loadAsync(url);
      geometry.computeVertexNormals();
      loaded = new THREE.Mesh(
        geometry,
        new THREE.MeshStandardMaterial({ color: 0xb9c2d0, roughness: 0.82, metalness: 0.02 })
      );
    } else {
      throw new Error('Formato .' + (ext || 'desconhecido') + ' não suportado. Use GLB, GLTF, FBX, OBJ ou STL.');
    }

    if (model) scene.remove(model);
    removeRig();
    model = loaded;
    model.name = file.name;
    model.traverse(o => {
      if ((o as THREE.Mesh).isMesh) {
        const mesh = o as THREE.Mesh;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        if (mesh.material) {
          const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          materials.forEach(m => {
            if ('side' in m) (m as THREE.Material).side = THREE.DoubleSide;
          });
        }
      }
    });
    scene.add(model);
    frameObject(model);
    updateStats();
    toast('Modelo importado: ' + file.name);
  } catch (e) {
    console.error('Falha ao importar modelo 3D:', e);
    const message = e instanceof Error ? e.message : 'Não foi possível importar o arquivo.';
    toast('Falha na importação: ' + message);
  } finally {
    URL.revokeObjectURL(url);
  }
};
type RigSegment = { child: THREE.Bone; start: THREE.Vector3; end: THREE.Vector3 };
const closestPointOnSegment = (point: THREE.Vector3, start: THREE.Vector3, end: THREE.Vector3) => {
  const direction = end.clone().sub(start);
  const lengthSq = direction.lengthSq();
  if (lengthSq < 1e-10) return start.clone();
  const t = THREE.MathUtils.clamp(point.clone().sub(start).dot(direction) / lengthSq, 0, 1);
  return start.clone().addScaledVector(direction, t);
};
const createHumanoidRig = () => {
  if (!model) { toast('Importe um personagem humanoide primeiro.'); return; }
  if (autoRigged || rootBone) { toast('Limpe o rig atual antes de criar outro.'); return; }
  const meshes: THREE.Mesh[] = [];
  let hasExistingSkin = false;
  model.traverse(object => {
    if ((object as THREE.SkinnedMesh).isSkinnedMesh) hasExistingSkin = true;
    else if ((object as THREE.Mesh).isMesh) meshes.push(object as THREE.Mesh);
  });
  if (hasExistingSkin) { toast('Este modelo já contém um esqueleto. Auto Rig foi cancelado.'); return; }
  if (!meshes.length) { toast('Nenhuma malha encontrada no modelo.'); return; }

  model.updateWorldMatrix(true, true);
  const worldBounds = new THREE.Box3().setFromObject(model);
  if (worldBounds.isEmpty()) { toast('Não foi possível medir o personagem.'); return; }
  const inverseModel = model.matrixWorld.clone().invert();
  const corners: THREE.Vector3[] = [];
  for (const x of [worldBounds.min.x, worldBounds.max.x])
    for (const y of [worldBounds.min.y, worldBounds.max.y])
      for (const z of [worldBounds.min.z, worldBounds.max.z])
        corners.push(new THREE.Vector3(x, y, z).applyMatrix4(inverseModel));
  const bounds = new THREE.Box3().setFromPoints(corners);
  const size = bounds.getSize(new THREE.Vector3());
  const center = bounds.getCenter(new THREE.Vector3());
  const height = size.y;
  if (height <= 1e-5 || size.x <= 1e-5) { toast('Dimensões inválidas para Auto Rig.'); return; }
  if (size.y < size.x * 0.72) { toast('Coloque o personagem em pé, com a cabeça para cima e os braços abertos em T-pose.'); return; }

  const y = (ratio: number) => bounds.min.y + height * ratio;
  const width = size.x;
  const depth = Math.max(size.z, height * 0.04);
  const boneList: THREE.Bone[] = [];
  const segments: RigSegment[] = [];
  const makeBone = (name: string, absolute: THREE.Vector3, parent: THREE.Bone | null, parentAbsolute?: THREE.Vector3) => {
    const bone = new THREE.Bone();
    bone.name = name;
    bone.position.copy(parentAbsolute ? absolute.clone().sub(parentAbsolute) : absolute);
    if (parent) parent.add(bone); else model!.add(bone);
    boneList.push(bone);
    if (parent) segments.push({ child: bone, start: parentAbsolute!.clone(), end: absolute.clone() });
    return bone;
  };
  const point = (x: number, yy: number, z = center.z) => new THREE.Vector3(x, yy, z);
  const hipsPos = point(center.x, y(0.52));
  const hips = makeBone('Hips', hipsPos, null);
  rootBone = hips;
  const spinePos = point(center.x, y(0.63));
  const spine = makeBone('Spine', spinePos, hips, hipsPos);
  const chestPos = point(center.x, y(0.75));
  const chest = makeBone('Chest', chestPos, spine, spinePos);
  const neckPos = point(center.x, y(0.86));
  const neck = makeBone('Neck', neckPos, chest, chestPos);
  const headPos = point(center.x, y(0.93));
  const head = makeBone('Head', headPos, neck, neckPos);
  makeBone('Head_End', point(center.x, y(0.99)), head, headPos);

  for (const sign of [-1, 1]) {
    const side = sign < 0 ? 'L' : 'R';
    const shoulderPos = point(center.x + sign * width * 0.19, y(0.75));
    const shoulder = makeBone(`Shoulder_${side}`, shoulderPos, chest, chestPos);
    const elbowPos = point(center.x + sign * width * 0.35, y(0.735));
    const elbow = makeBone(`UpperArm_${side}`, elbowPos, shoulder, shoulderPos);
    const wristPos = point(center.x + sign * width * 0.465, y(0.72));
    const wrist = makeBone(`Forearm_${side}`, wristPos, elbow, elbowPos);
    makeBone(`Hand_${side}`, point(center.x + sign * width * 0.50, y(0.715)), wrist, wristPos);

    const upperLegPos = point(center.x + sign * width * 0.065, y(0.49));
    const upperLeg = makeBone(`UpperLeg_${side}`, upperLegPos, hips, hipsPos);
    const kneePos = point(center.x + sign * width * 0.07, y(0.28));
    const knee = makeBone(`LowerLeg_${side}`, kneePos, upperLeg, upperLegPos);
    const anklePos = point(center.x + sign * width * 0.07, y(0.075));
    const ankle = makeBone(`Foot_${side}`, anklePos, knee, kneePos);
    makeBone(`Toe_${side}`, point(center.x + sign * width * 0.07, y(0.035), center.z + depth * 0.18), ankle, anklePos);
  }

  model.updateWorldMatrix(true, true);
  const orderedBones: THREE.Bone[] = [];
  hips.traverse(object => { if ((object as THREE.Bone).isBone) orderedBones.push(object as THREE.Bone); });
  const boneIndices = new Map<THREE.Bone, number>();
  orderedBones.forEach((bone, index) => boneIndices.set(bone, index));
  const skeleton = new THREE.Skeleton(orderedBones);
  const radius = height * 0.012;

  try {
    for (const mesh of meshes) {
      const originalGeometry = mesh.geometry;
      const geometry = originalGeometry.clone();
      const positions = geometry.getAttribute('position');
      if (!positions) continue;
      const skinIndices = new Uint16Array(positions.count * 4);
      const skinWeights = new Float32Array(positions.count * 4);
      mesh.updateWorldMatrix(true, false);
      for (let vertex = 0; vertex < positions.count; vertex++) {
        const localPosition = new THREE.Vector3(positions.getX(vertex), positions.getY(vertex), positions.getZ(vertex));
        const inModel = localPosition.applyMatrix4(mesh.matrixWorld).applyMatrix4(inverseModel);
        const nearest = segments.map(segment => {
          const closest = closestPointOnSegment(inModel, segment.start, segment.end);
          return { index: boneIndices.get(segment.child) ?? 0, distanceSq: closest.distanceToSquared(inModel) };
        }).sort((a, b) => a.distanceSq - b.distanceSq).slice(0, 4);
        let total = 0;
        const raw = nearest.map(item => 1 / (item.distanceSq + radius * radius));
        total = raw.reduce((sum, value) => sum + value, 0);
        nearest.forEach((item, influence) => {
          const offset = vertex * 4 + influence;
          skinIndices[offset] = item.index;
          skinWeights[offset] = raw[influence] / total;
        });
      }
      geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(skinIndices, 4));
      geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(skinWeights, 4));

      const parent = mesh.parent;
      if (!parent) continue;
      const index = parent.children.indexOf(mesh);
      const skinned = new THREE.SkinnedMesh(geometry, mesh.material);
      skinned.name = mesh.name;
      skinned.position.copy(mesh.position);
      skinned.quaternion.copy(mesh.quaternion);
      skinned.scale.copy(mesh.scale);
      skinned.rotation.order = mesh.rotation.order;
      skinned.matrix.copy(mesh.matrix);
      skinned.matrixAutoUpdate = mesh.matrixAutoUpdate;
      skinned.visible = mesh.visible;
      skinned.castShadow = mesh.castShadow;
      skinned.receiveShadow = mesh.receiveShadow;
      skinned.frustumCulled = mesh.frustumCulled;
      skinned.renderOrder = mesh.renderOrder;
      skinned.userData = { ...mesh.userData };
      parent.add(skinned);
      parent.remove(mesh);
      const newIndex = parent.children.indexOf(skinned);
      if (newIndex >= 0) {
        parent.children.splice(newIndex, 1);
        parent.children.splice(Math.min(index, parent.children.length), 0, skinned);
      }
      skinned.bind(skeleton);
      riggedMeshes.push({ parent, original: mesh, skinned, index });
    }
    if (!riggedMeshes.length) throw new Error('Não foi possível vincular pesos às malhas.');
    autoRigged = true;
    boneCount = orderedBones.length;
    lastBone = null;
    addBoneMode = false;
    $('boneModeBtn').classList.remove('active');
    $('modeLabel').textContent = 'AUTO RIG BETA';
    if (skeletonHelper) scene.remove(skeletonHelper);
    skeletonHelper = new THREE.SkeletonHelper(hips);
    skeletonHelper.material = new THREE.LineBasicMaterial({ color: 0x62e6c5, depthTest: false });
    scene.add(skeletonHelper);
    updateStats(); refreshBoneList(); syncPosePanel();
    $('tipBox').innerHTML = '<b>Auto Rig humanoide · beta</b><span>Esqueleto e pesos iniciais foram aplicados. Teste movimentos suaves antes de usar em uma animação. Personagens fora de T-pose podem exigir ajuste manual; pintura de pesos ainda não está disponível.</span>';
    toast(`Auto Rig criado: ${boneCount} ossos em ${riggedMeshes.length} malha(s).`);
  } catch (error) {
    console.error(error);
    removeRig();
    toast(error instanceof Error ? `Falha no Auto Rig: ${error.message}` : 'Falha ao criar Auto Rig.');
  }
};

const toggleBoneMode = () => {
  if (!model) { toast('Importe um modelo antes de criar ossos.'); return; }
  if (autoRigged) { toast('Limpe o Auto Rig antes de criar uma cadeia manual.'); return; }
  addBoneMode = !addBoneMode;
  $('boneModeBtn').classList.toggle('active', addBoneMode);
  $('modeLabel').textContent = addBoneMode ? 'BONE PLACEMENT' : 'VIEW MODE';
  $('tipBox').innerHTML = addBoneMode
    ? '<b>Posicionamento de ossos ativo</b><span>Toque no modelo para criar o primeiro osso e continue tocando para criar os filhos na sequência. Desative o modo para navegar pela câmera.</span>'
    : '<b>Modo de visualização</b><span>Arraste para orbitar e use pinça para zoom. Reative Adicionar osso para continuar a cadeia.</span>';
  toast(addBoneMode ? 'Toque na superfície para posicionar um osso.' : 'Modo de visualização ativado.');
};
const placeBone = (point3: THREE.Vector3) => {
  const bone = new THREE.Bone();
  bone.name = `Bone_${String(boneCount + 1).padStart(2, '0')}`;
  if (!rootBone) {
    rootBone = bone;
    bone.position.copy(point3);
    scene.add(rootBone);
  } else if (lastBone) {
    const parentWorld = new THREE.Vector3();
    lastBone.getWorldPosition(parentWorld);
    bone.position.copy(point3).sub(parentWorld);
    lastBone.add(bone);
  }
  lastBone = bone;
  boneCount++;
  if (skeletonHelper) { scene.remove(skeletonHelper); }
  skeletonHelper = new THREE.SkeletonHelper(rootBone!);
  skeletonHelper.material = new THREE.LineBasicMaterial({ color: 0x62e6c5, depthTest: false });
  scene.add(skeletonHelper);
  updateStats(); refreshBoneList();
};
renderer.domElement.addEventListener('pointerdown', event => {
  if (!addBoneMode || !model) return;
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObject(model, true);
  if (hits.length) placeBone(hits[0].point);
  else toast('Toque em uma superfície do modelo.');
});
const importFile = () => $('fileInput').click();
$('importBtn').addEventListener('click', importFile);
$('emptyImport').addEventListener('click', importFile);
$('fileInput').addEventListener('change', e => {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (file) void loadModel(file);
  (e.target as HTMLInputElement).value = '';
});
$('boneModeBtn').addEventListener('click', toggleBoneMode);
$('autoRigBtn').addEventListener('click', createHumanoidRig);
$('poseBoneSelect').addEventListener('change', event => {
  const index = Number((event.target as HTMLSelectElement).value);
  selectedPoseBone = poseBones[index] || null;
  updatePoseSliders();
});
(['X', 'Y', 'Z'] as const).forEach(axis => {
  $('pose' + axis).addEventListener('input', event => {
    applyPoseRotation(axis.toLowerCase() as 'x' | 'y' | 'z', (event.target as HTMLInputElement).value);
  });
});
$('resetBonePose').addEventListener('click', resetSelectedPoseBone);
$('resetAllPose').addEventListener('click', resetEntirePose);
syncPosePanel();
$('clearBonesBtn').addEventListener('click', () => { removeRig(); $('modeLabel').textContent = 'VIEW MODE'; toast('Rig removido e malhas restauradas.'); });
$('undoBoneBtn').addEventListener('click', () => {
  if (autoRigged) { toast('Use Limpar rig antes de alterar um Auto Rig.'); return; }
  if (!lastBone || !rootBone) { toast('Não há ossos para desfazer.'); return; }
  const parent = lastBone.parent;
  if (parent) parent.remove(lastBone);
  if (boneCount > 1 && parent instanceof THREE.Bone) lastBone = parent;
  else { scene.remove(rootBone); rootBone = null; lastBone = null; }
  boneCount = Math.max(0, boneCount - 1);
  if (skeletonHelper) { scene.remove(skeletonHelper); skeletonHelper = rootBone ? new THREE.SkeletonHelper(rootBone) : null; if (skeletonHelper) { skeletonHelper.material = new THREE.LineBasicMaterial({color:0x62e6c5, depthTest:false}); scene.add(skeletonHelper); } }
  updateStats(); refreshBoneList(); toast('Último osso removido.');
});
$('fitBtn').addEventListener('click', () => model ? frameObject(model) : toast('Importe um modelo primeiro.'));
$('resetViewBtn').addEventListener('click', () => { camera.position.set(3,2.2,4); controls.target.set(0,1,0); controls.update(); });
$('helpBtn').addEventListener('click', () => toast('Importe um humanoide em pé e use Auto Rig humanoide (beta), ou crie ossos manualmente.'));
const resize = () => {
  const w = viewport.clientWidth, h = viewport.clientHeight;
  if (!w || !h) return;
  camera.aspect = w / h; camera.updateProjectionMatrix(); renderer.setSize(w, h);
};
new ResizeObserver(resize).observe(viewport); resize();
const animate = () => { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); };
animate();
updateStats();

